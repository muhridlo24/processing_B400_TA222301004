import numpy as np
import torch
import torch.nn as nn
from torch import sigmoid, tanh
import torch.optim as optim
import firebase_admin
from firebase_admin import credentials, initialize_app, firestore,storage
from flask import Flask, request, jsonify
from datetime import datetime
import joblib
import random
import string
import pytz

cred = credentials.Certificate('function-framework/tutorial-flask/run/processing/my-test-project-373716-firebase-adminsdk-nyuqz-bc57b26b33.json')

torch.manual_seed(0)
torch.set_default_dtype(torch.float32)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
default_app=initialize_app(cred)
db = firestore.client() #ini yang manggil firestore
app = Flask(__name__)

warn_ref = db.collection('warning') #reference to warning
machine_ticket_ref=db.collection('ticket_fromMachine')

'''
Langkah kode program:
1. Membuat fungsi untuk trigger-able processing. Trigger dilakukan oleh mini PC setiap kali data diterima (ini di akhir krn ada tambahan kode trigger).
2. Membuat fungsi untuk mengambil file model dari storage firebase (bucket).
3. Membuat kode program untuk memanggil fungsi predict di dalam Flask.
4. Membuat kode program untuk menyimpan keluaran dari fungsi predict tersebut ke dalam variabel.
5. Membuat kode untuk menyimpan variabel keluaran fungsi predict ke dalam firestore -> /processed.
'''

"""Triggerable processing"""
@app.route("/warning-machine",methods=["GET","POST"])
def processing():
    tm=datetime.now()
    if(request.method=='POST'):
        try:   
            data=request.json

        except KeyError:
            return jsonify({'error': "No text sent"})

        try:
            date=data['time']
            line=data['line']
            plant=data['plant']
            zona=data['zona']
            deviceName=data['machine_id']
            temp=data['temperature']
            vib=[[float(i) for i in data['vibration']['wavelet'].split(',')]]
            rms_vib=[data['vibration']['rms_category'],data['vibration']['rms_value']]

            rpm=data['rpm']

            message_vib = predict_pipeline(vib,rms_vib)
            print(datetime.now()-tm)
            message_temp=temperature(temp)
            print(datetime.now()-tm)
            message_rpm=rpm_process(rpm)
            print(datetime.now()-tm)
            priority_list=[message_vib['priority'],message_temp['priority'],message_rpm['priority']]
            priority_index=['Vibrasi','Temperatur','RPM']
            priority=max(priority_list)
            idx_priority=[priority_index[i] for i in range(len(priority_list)) if(priority_list[i]==2)]
            print(datetime.now()-tm)

            if(priority==2):
                unique_title="Masalah " + ', '.join(idx_priority)
                details='''Detected at {} with details:\n
                        Temperature: {}\n,
                        RPM: {}\n,
                        Vibration: {}'''.format(date,message_temp['message'],
                                                message_rpm['message'],
                                                message_vib['message'])
                
                data_for_ticket={
                    'id':''.join(random.choices(string.ascii_letters, k=8)),
                    'title':unique_title,
                    'detail':details,
                    'issuer':"Machine",
                    'machine_id':deviceName,
                    'plant':plant,
                    'priority':priority,
                    'status':1,
                    'created':datetime.now(pytz.timezone('Asia/Bangkok')),
                    'deadline':datetime.now(pytz.timezone('Asia/Bangkok')),
                    'modified':datetime.now(pytz.timezone('Asia/Bangkok'))}

                """kirim data ke database bagian ticketing"""
                machine_ticket_ref.document().set(data_for_ticket, merge=True)
                
                message="Successfully sent with execution time " + str(datetime.now()-tm)
                print(message)
                return jsonify(message=message, data=data), 200
            else:
                print("gaada masalah bang")
                return jsonify(message="No warning detected :)"), 200
            
        except Exception as e:   
            return jsonify({'error': str(e)}) 

def rpm_process(data):
    message=""

    if(data['stability']=="Unstable"):
        message=message+"RPM unstable at "+str(round(data['value'],2))
        priority_1=2
    elif(data['stability']=="Stable"):
        message=message+"RPM Stable at "+str(round(data['value'],2))
        priority_1=0

    if(data['stat']=="Higher"):
        message=message+'\nRPM is higher than standard'
        priority_2=2
    elif(data['stat']=="Lower"):
        priority_2=2
        message=message+'\nRPM is lower than standard'
    else:
        priority_2=0

    priority=max([priority_1,priority_2])
    message=message+"\nRPM deviation is "+str(round(data['std'],2))

    result={
        "message":message,
        "priority":priority
    }

    return result

def temperature(data):
    message=""
    prior=-1

    if(data['status']=="Danger"):
        message+="Temperature is in danger, Currently at "+ str(data['value'])
        prior=2   
    elif(data['status']=="High"):
        message+="Temperature is high, Currently at "+ str(data['value'])
        prior=1
    elif(data['status']=="Warm"):
        message+="Temperature is warm, Currently at "+ str(data['value'])
        prior=0
    elif(data['status']=="Normal"):
        message+="Temperature is normal"
        prior=-1
    
    if(data['trend']>0):
        trend="rising"
    elif(data['trend']<0):
        trend='decreasing'
    else:
        trend='Stable'

    message = message + "\nTemperature is {} with gradient of {}".format(trend,data['trend'])
    result={
        "message":message,
        "priority":prior
    }

    return result

"""Memanggil Fungsi Predict di dalam task"""
def predict_pipeline(data,value):
    try:
        TIME_STEPS = 50
        NUM_UNITS = 128
        LEARNING_RATE = 0.001
        message=""

        data = np.array(data).reshape(len(data), -1, 1)
        model = JANet(inputs=1, cells=NUM_UNITS, num_outputs=14, num_timesteps=TIME_STEPS,output_activation=nn.Softmax(dim=1))
        model.load_state_dict(torch.load("function-framework/tutorial-flask/run/processing/coba_1.pkl"),strict=False)

        optimizer = optim.Adam(list(model.parameters()), lr=LEARNING_RATE)
        optimizer.zero_grad()
        pred=model(torch.from_numpy(data.astype('float32')).to(device))
        pred=pred.cpu().detach().numpy().flatten().tolist()
        # print(pred)
        sorted_list = sorted(pred, reverse=True)
        # [50, 40, 30, 20, 10]

        first = pred.index(sorted_list[0])
        second = pred.index(sorted_list[1])
        third = pred.index(sorted_list[2])

        message_1,message_2,message_3=enterpret(first),enterpret(second),enterpret(third)
        message=message_1+" "+str(round(sorted_list[0]*100,2))+"%\n"+message_2+" "+str(round(sorted_list[1]*100,2))+"%\n"+message_3+" "+str(round(sorted_list[2]*100,2))+"%"

        if(first==3 or first==8 or first==9 or first==10 or first==13):
            priority=2
        elif(first==2 or first==7 or first==12):
            priority=1
        elif(first==1 or first==4 or first==5 or first==6 or first==11):
            priority=0
        else:
            priority=-1

        if(value[0]=="Danger"):
            priority_2=2
        elif(value[0]=="Alert"):
            priority_2=2
        elif(value[0]=='Satisfactory'):
            priority_2=1
        elif(value[0]=='Good'):
            priority_2=0
        
        message=message+"\nRMS Vibration Velocity is in {} with value of {} m/s RMS".format(value[0],value[1])

        priority=max([priority,priority_2])

        result={
            "message":message,
            "priority":priority
        }
        return result
    
    except TypeError:
        pass
    
    except ValueError:
        pass

def enterpret(data):
    if(data==0):
        return 'Normal'
    elif(data==1):
        return "Inner Race Mild"
    elif(data==2):
        return "Inner Race Medium"
    elif(data==3):
        return 'Inner Race Severe'
    elif(data==4 or data==5 or data==6):
        return "Outer Race Mild"
    elif(data==7):
        return "Outer Race Medium"
    elif(data==8 or data==9 or data==10):
        return "Outer Race Severe"
    elif(data==11):
        return "Ball Mild"
    elif(data==12):
        return "Ball Medium"
    elif(data==13):
        return "Ball Severe"

#utilities
class JANet(nn.Module):
    def __init__(self, inputs, cells, num_outputs, num_timesteps, output_activation=None):
        super(JANet, self).__init__()
        
        self.inputs = inputs
        self.cells = cells
        self.classes = num_outputs
        self.num_timesteps = num_timesteps
        self.output_activation = output_activation
        
        kernel_data = torch.zeros(inputs, 2 * cells, dtype=torch.get_default_dtype())
        kernel_data = torch.nn.init.xavier_uniform_(kernel_data)
        self.kernel = nn.Parameter(kernel_data)
        
        recurrent_kernel_data = torch.zeros(cells, 2 * cells, dtype=torch.get_default_dtype())
        recurrent_kernel_data = torch.nn.init.xavier_uniform_(recurrent_kernel_data)
        self.recurrent_kernel = nn.Parameter(recurrent_kernel_data)
        
        recurrent_bias = np.zeros(2 * cells)
        # chrono initializer
        recurrent_bias[:cells] = np.log(np.random.uniform(1., self.num_timesteps - 1, size=cells))
        recurrent_bias = recurrent_bias.astype('float32')
        self.recurrent_bias = nn.Parameter(torch.from_numpy(recurrent_bias))
        
        self.output_dense = nn.Linear(cells, num_outputs)
        
    def forward(self, inputs):
        h_state = torch.zeros(inputs.size(0), self.cells, dtype=torch.get_default_dtype()).to(device)
        c_state = torch.zeros(inputs.size(0), self.cells, dtype=torch.get_default_dtype()).to(device)
        
        num_timesteps = inputs.size(1)
        
        for t in range(num_timesteps):
            ip = inputs[:, t, :]
            
            z = torch.mm(ip, self.kernel)
            z += torch.mm(h_state, self.recurrent_kernel) + self.recurrent_bias
            
            z0 = z[:, :self.cells]
            z1 = z[:, self.cells: self.cells * 2]
            
            f = sigmoid(z0)
            c = f * c_state + (1. - f) * tanh(z1)
            
            h = c
            
            h_state = h
            c_state = c
        
        preds = self.output_dense(h_state)
        
        if self.output_activation is not None:
            preds = self.output_activation(preds)
        
        return preds

if __name__=="__main__":
    app.run(debug=True)