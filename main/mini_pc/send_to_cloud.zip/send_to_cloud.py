import firebase_admin
import pandas as pd
import pywt
import numpy as np
from scipy.signal import butter, lfilter
from datetime import datetime

cred_obj = firebase_admin.credentials.Certificate('D:/b400/mini_pc/my-test-project-373716-firebase-adminsdk-nyuqz-bc57b26b33.json')
default_app = firebase_admin.initialize_app(cred_obj, {
	'databaseURL':'https://my-test-project-373716-default-rtdb.asia-southeast1.firebasedatabase.app/'
	})

from firebase_admin import db
import json

ref = db.reference("/machines/")

def temperature(deviceName,data):
    if(deviceName=='LHL01'):
        if(data > 50):
            pass
    elif(deviceName=='Pompa'):
        if(data > 50):
            pass

def vibration_preprocessing(data):
    pass
        
def bandpass(x):
  # Cut-off frequency of the filter (in Hz)
  lowcut = 60
  highcut = 200

  # Sampling rate of the data (in Hz)
  fs = 1000

  # Filter order
  order = 2

  # Design the band-pass Butterworth filter
  nyquist = 0.5 * fs
  low = lowcut / nyquist
  high = highcut / nyquist
  b, a = butter(order, [low, high], btype='band', analog=False)

  # Apply the filter to the data
  y = lfilter(b, a, x)

  return y

def apply_fft(x, fs, num_samples):
    f = np.linspace(0.0, (fs/2.0), num_samples//2)
    freq_values = np.fft.fft(x)
    freq_values = 2.0/num_samples * np.abs(freq_values[0:num_samples//2])
    return f, freq_values

def wavelet_new(sinyal):
  temp = pywt.WaveletPacket(data=sinyal, wavelet='db4', mode='symmetric')
  x = [node.path for node in temp.get_level(3, 'natural')]
  temp_feature = [np.sum((temp[i].data)**2) for i in x]

  for i in x:
    new_wp = pywt.WaveletPacket(data = None, wavelet = 'db4', mode='symmetric',maxlevel=3)
    new_wp[i] = temp[i].data
    reconstructed_signal = new_wp.reconstruct(update = False) # Signal reconstruction from wavelet packet coefficients
    f, c = apply_fft(reconstructed_signal, 48000, len(reconstructed_signal))

    z = abs(c)

    # Find  m  highest amplitudes of the spectrum and their corresponding frequencies:
    maximal_idx = np.argpartition(z, -1)[-1:]
    high_amp = z[maximal_idx]
    high_freq = f[maximal_idx]
    feature = high_amp*high_freq
    temp_feature.append(list(high_amp)[0])
    temp_feature.append(list(high_freq)[0])
    temp_feature.append(list(feature)[0])

  return temp_feature

def wav_feature_new(dat_1,length,col):
  merged_dat = pd.DataFrame()

  for i in range(len(dat_1.fault.unique())):
    temp = dat_1.loc[dat_1.fault==dat_1.fault.unique()[i]]
    wavelett = [wavelet_new(temp.iloc[xx:xx+length,col].values)
                if (xx+length<temp.shape[0]) else wavelet_new(temp.iloc[xx:temp.shape[0],col].values)
                for xx in range(0,temp.shape[0],length)]

    fault = [temp.iloc[0,-1] for k in range(0,temp.shape[0],length)]
      
    res_dat = pd.concat([pd.DataFrame(wavelett),
                        pd.DataFrame(fault)],axis=1)
    
    merged_dat = pd.concat([merged_dat,res_dat],axis=0)
    
  return merged_dat

def send(time,line,plant,zona,deviceName,temp,rpm,vib_mean):
    ref_1 = ref.child(str(deviceName))
    # ref_1.child('id').push().set({"Timestamp":time,
    #                         "Value":deviceName})
    # ref_1.child('line').push().set({"Timestamp":time,
    #                                 "Value":line})
    # ref_1.child('performance_log').push().set({"Timestamp": time,
    #                                "Temperature": temp,
    #                                "RPM": rpm,
    #                                "Vibration": vib_mean})
    # ref_1.child('plant').push().set({"Timestamp":time,
    #                                  "Value":plant})
    # ref_1.child('zona').push().set({"Timestamp":time,
    #                                 "Value":zona})
    ref_1.push().set({"Timestamp":time,
                      "id":deviceName,
                      "line":line,
                      "performance_log":{"Temperature":temp,
                                         "RPM":rpm,
                                         "Vibration":vib_mean},
                      "plant":plant,
                      "zona":zona})

deviceName="LHL01"
line="Line 1"
plant="J2"
zona="Zona A"
time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(time)
data = send(time,line,plant,zona,deviceName,70,10,10)
 